#!/bin/bash -eE

echo "Start to make update.img..."
rm -f output/update.img
./afptool -pack output output/update.img.tmp
./rkImageMaker -RK3588 output/MiniLoaderAll.bin output/update.img.tmp output/update.img -os_type:androidos
rm -f output/update.img.tmp
sync
echo "Making update.img OK: ./output/update.img"
