#!/bin/bash -eE

echo "Start to unpack update.img..."
rm -rf output && mkdir output
./rkImageMaker -unpack ../../../../update.img output
./afptool -unpack output/firmware.img output
rm -f output/firmware.img
rm -f output/boot.bin

sed -i 's|Image\/||' output/package-file
mv -f output/Image/* output 2>/dev/null || true
rm -rf output/Image
sync
echo "Unpacking update.img OK: ./output"
